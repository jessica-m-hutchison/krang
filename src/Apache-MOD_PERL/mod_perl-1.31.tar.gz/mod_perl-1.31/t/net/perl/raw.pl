#!perl

print "HTTP/1.0 200 OK\n";
print "Content-type: text/plain\n\n";
print "OK";
